﻿using UnityEngine;
using System.Collections;

public class BatteryHealth : MonoBehaviour {

	public float batteryFull = 70.0f; // battery life in seconds
	float batteryRemaining; // remaining battery life in seconds
	int percentRemaining; // converted to percent
	internal bool trackingBattery = true; // timer not started
	GUIText guiTxt; // the GUI Text component
	public GameObject energyBar; //the battery's energy bar sprite
	float baseScale; // the energy bar's base y scale

	// Use this for initialization
	void Start () {
		batteryRemaining = batteryFull; // full charge
		guiTxt = GetComponent<GUIText>(); // the GUI Text object
		guiTxt.text = "100%"; // full charge- assigned
		
		baseScale = energyBar.transform.localScale.y; // get the base scale
	}
	
	// Update is called once per frame
	void Update () {
		if(trackingBattery) {
		   if (batteryRemaining > 0){
		      batteryRemaining -= Time.deltaTime; // second countdown
		      percentRemaining = (int)((batteryRemaining / batteryFull) * 100); // round off for percent
		      UpdateBattery(); // update the sprite graphic
			  guiTxt.text = percentRemaining.ToString() + "%";
		   }
		   else {
			   GameOver(); // it has run out
			   trackingBattery = false; // turn off	battery timer
			}

		}
	
	}
	
	void  GameOver(){
	   // deactive the potato gun firing    
	   GameObject.Find("Fire Point").SetActive(false); 
		// disable navigation
		GameObject.Find("Gnomatic Garden Defender").GetComponent<CharacterMotor>().enabled = false; 
		// disable turning
		GameObject.Find("Gnomatic Garden Defender").GetComponent<MouseLook>().enabled = false;
		//disable weapon aiming
		GameObject.Find("Arm Group").GetComponent<MouseLook>().enabled = false;
		
	
	}

	// animate the battery's energy bar sprite to match percent remaining
	void UpdateBattery () { 
		// adjust battery's energy bar sprite
		Vector3 adjustedScale = energyBar.transform.localScale; //store the sprite's scale in a temp var
		adjustedScale.y = baseScale *  (batteryRemaining / batteryFull); // calculate the actual y scale
		energyBar.transform.localScale = adjustedScale; // apply the new value
		// if less than 50% and greater than 25%, adjust color- raise red to get yellow
		if(percentRemaining <= 50 && percentRemaining > 25) {
		   float adj = (50- percentRemaining) * 0.04f; // adjusted for current percent 
		   energyBar.GetComponent<SpriteRenderer>().color = new Color(0f + adj,1f,0f);
		}
		// if less than or equal to 25%, adjust color drop green to get red 
		if(percentRemaining <= 25 ) {
		   float adj = (25 - percentRemaining) * 0.04f;
		   energyBar.GetComponent<SpriteRenderer>().color = new Color(1f,1f - adj,0f);
		}
	
	}

}
