﻿using UnityEngine;
using System.Collections;

public class GameMisc : MonoBehaviour {

	LevelManager levelManager; // the script that holds the data between levels
	public Transform gnomeTransform; // the gnome's transform
	
	// needed for level hopping
	public ScoreKeeper scoreKeeper; // where the current bun count is kept (on the Game Manager)
	public BatteryHealth batteryHealth; // where the battery charge is tracked (on the Battery Life)

	public GameObject[] hideShows; // the objects that are affected by occlusion culling

	// Use this for initialization
	void Start () {
		// prevent baby zombie bunnies from colliding with bundle
		Physics2D.IgnoreLayerCollision(8,9,true);
		
		if(GameObject.Find("Level Manager")) {
		   levelManager = GameObject.Find("Level Manager").GetComponent<LevelManager>();
		   // if this is a new game, send the initial data
		   if(levelManager.gameState == 0) LevelPrep (); 
		}

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.F1)) {
		   Screen.showCursor = true; // show the cursor
			LevelPrep (); // do data collection before going to the new level
		   //Application.LoadLevel(1); // load the Main Menu
			StartCoroutine(LoadTheLevel());
		}
	
	}
	
	void LevelPrep () {
	   if(levelManager) {
	      // send the gnome's transform off to be saved if the levelManager has been found
	      Transform temptrans = gnomeTransform;
	      levelManager.gnomePos = temptrans.position; 
	      levelManager.gnomeYRot = temptrans.localEulerAngles.y;
			
			// send the current zombie bunnie count
			levelManager.bunCount = scoreKeeper.currentBunCount;
			// send the battery info
			//levelManager.batteryRemaining = batteryHealth.batteryRemaining;
			levelManager.percentRemaining = batteryHealth.percentRemaining;
			
			// send the hide/show areas' current active states off to be stored
			for (int x = 0 ; x < hideShows.Length; x++) {			
				levelManager.areaVisibility[x] = hideShows[x].activeSelf;		
			}			
	   }
	}
	
	IEnumerator LoadTheLevel() {
	   // makes sure all the storage tasks have been completed
	   yield return new WaitForSeconds(0.1f);
	   Application.LoadLevel("MainMenu"); // load the Main Menu
	}

	public void LoadVis () {
		// retrieve the hide/show areas' current states and apply them
		for (int x = 0 ; x < hideShows.Length ; x++) {			
		   hideShows[x].SetActive(levelManager. areaVisibility [x]);		
		}
	}		
	
}
