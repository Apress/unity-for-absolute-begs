﻿using UnityEngine;
using System.Collections;

public class CreditsGUI : MonoBehaviour {
	
	public GUISkin newSkin; // custom skin to use
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI () {
		
	   GUI.skin = newSkin;
			
	   // Constrain all drawing to be within a 600x600 pixel area centered on the screen.
	   GUI.BeginGroup (new Rect (Screen.width / 2 - 300, Screen.height / 2 - 350, 600, 600));
	
			// Draw a box in the new coordinate space defined by the BeginGroup.
			GUI.Box (new Rect (0,0,600,600),"Credits");
			
				int y = 240; // base Y position
				int x = 150; // base x inset 
				int yOffset = 60; // y offset
				
				y+= yOffset;
				// title
				GUI.Label(new Rect (x, y, 300, 60), "Game Design","left_label");
				
				
				// person
				GUI.Label(new Rect (x, y, 300, 60), "your name here", "right_label");
				y+= yOffset;
				
				// date
				GUI.Label(new Rect (100, 370, 400, 40), "XXIV");
				y+= yOffset;
				
				// Main Menu
				if (GUI.Button( new Rect (200,420,200,40), "Main Menu")) {
				   // Back to Main Menu 
				   Application.LoadLevel("MainMenu");
				}

	
	   // must match all BeginGroup calls with an EndGroup
	   GUI.EndGroup ();
	}

	
}
