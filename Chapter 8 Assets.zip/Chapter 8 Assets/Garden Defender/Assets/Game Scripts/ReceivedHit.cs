﻿using UnityEngine;
using System.Collections;

public class ReceivedHit : MonoBehaviour {
	
	public GameObject gameManager; // the master repository for game info
	public GameObject deadReplacement; // this will be the ToastedZombie
	public GameObject smokePlume; // smoke particle system
	int damage = 0; // accumulated damage points
	
	// Use this for initialization
	void Start () {
		gameManager = GameObject.Find("Game Manager"); // identify and assign the Game Manager object
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
//	void OnCollisionEnter (Collision collision) {
//	   if (collision.transform.tag == "Ammo") {
//			Destroy(collision.gameObject); // destroy the potato
//		  // if it was hit by something tagged as a Ammo, process its destruction
//	      DestroyBun(); 
//	   }
//	}
		
	void DestroyBun () {
		
		if (deadReplacement) {
			// get the dead replacement object's parent
			GameObject deadParent = deadReplacement.transform.parent.gameObject;
		   // instantiate the dead replacement's parent at this object's transform
		   GameObject dead = (GameObject) Instantiate(deadParent, transform.position, transform.rotation);
		   // trigger its default animation
		   deadReplacement.GetComponent<Animator>().Play("Jump Shrink");
		   // destroy the dead replacement's parent after a second
		   Destroy(dead,1.0f); 
			GameObject plume = (GameObject) Instantiate(smokePlume, transform.position, smokePlume.transform.rotation);
			// trigger it to be destroyed at its end/Duration + max lifetime
			Destroy(plume,10f);
			
			
		}
		
		// send the amount to update the total
		gameManager.SendMessage("UpdateCount",-1, SendMessageOptions.DontRequireReceiver);
	
     	Destroy(gameObject, 0.001f); // destroy it after a brief pause
	}
	
	void Terminator (int newDamage) {
	   damage += newDamage; // add more damage from 
	   //print (damage);
	   if (damage > 10) DestroyBun();
	}
		
		

	
}
