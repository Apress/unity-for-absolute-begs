﻿using UnityEngine;
using System.Collections;

public class SettingsGUI : MonoBehaviour {
	
	public GUISkin newSkin; // custom skin to use

	float diffSliderValue = 5.0f; // difficulty slider
	float ambSliderValue = 1.0f; // ambient volume slider
	
	LevelManager levelManager; // the script that holds the data between levels

	// Use this for initialization
	void Start () {
		if(GameObject.Find("Level Manager")) {
		   levelManager = GameObject.Find("Level Manager").GetComponent<LevelManager>();
			ambSliderValue = levelManager.ambientVolume; // set the volume to the stored value 
			diffSliderValue = levelManager.difficulty; // set the difficulty to the stored value

		}
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI () {
		
	   GUI.skin = newSkin;
			
	   // Constrain all drawing to be within a 600x600 pixel area centered on the screen.
	   GUI.BeginGroup (new Rect (Screen.width / 2 - 300, Screen.height / 2 - 350, 600, 600));
	
			// Draw a box in the new coordinate space defined by the BeginGroup.
			GUI.Box (new Rect (0,0,600,600),"Settings");	
			
			int y = 240; // base Y position
			int x = 200; // base x inset
			int yOffset = 60; // y offset
					
			// difficulty slider
			GUI.Label(new Rect (x - 50, y, 300, 60), "Difficulty");
			y+= yOffset;
			diffSliderValue = GUI.HorizontalSlider (new Rect (x, y, 200, 60), diffSliderValue, 10.0f, 0f);
			y+= yOffset - 25;
			// ambient volume slider
			GUI.Label(new Rect (x - 50, y, 300, 60), "Ambient Sound Volume");
			y+= yOffset;
			ambSliderValue = GUI.HorizontalSlider (new Rect (x, y, 200, 60), ambSliderValue, 0.0f, 1.0f);
			
			if (GUI.Button( new Rect (200,y + 40,200,40), "Main Menu")) {
			   // Back to Main Menu    
			   Application.LoadLevel("MainMenu");
			}

	
	   // must match all BeginGroup calls with an EndGroup
	   GUI.EndGroup ();
		
		if (GUI.changed) {
		   audio.volume = ambSliderValue; // adjust the audio clip's volume
			
			// Send updated values back to LevelManager 
			if (levelManager) {
			   levelManager.ambientVolume = ambSliderValue;
			   levelManager.difficulty = (int)(diffSliderValue);
			}
			
			
		}
		
		//print (	diffSliderValue + "  " + ambSliderValue); 
	}

	
}
