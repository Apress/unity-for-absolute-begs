﻿using UnityEngine;
using System.Collections;

public class LaserBeam : MonoBehaviour {
	
	int range = 30; // the distance to check within 
	
	public Light hitLight; // the light for the end of the laser
	
	public GameObject hitParticles;// the sparks prefab
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		// Did we hit anything?
		RaycastHit hit; // holds some of the object properties that are detected with the raycast
		if (Physics.Raycast (transform.position, transform.forward, out hit, range)) { 
		   Vector3 pos = new Vector3(0, 0,hit.distance); // create the new end value
		   GetComponent<LineRenderer>().SetPosition (1,pos); // also on the Laser Point
			
			if (hitParticles) { // if particles were assigned, instantiate them at the hit point
				GameObject temp = (GameObject) Instantiate(hitParticles, hit.point,Quaternion.FromToRotation(Vector3.up, hit.normal));
				Destroy(temp, 0.3f);
			}
		   //update end position			
			Vector3 lightPos = new Vector3(0, 0,hit.distance-0.2f); //calculate and offset from the hit pt
			hitLight.transform.localPosition = lightPos; // move the light to the hit point
			
			if(hit.collider.tag == "Invader") {
			   hit.collider.SendMessage ("DestroyBun",SendMessageOptions.DontRequireReceiver);
			   hitLight.audio.Play(); // cue the fx
			}

		}
	}
}
