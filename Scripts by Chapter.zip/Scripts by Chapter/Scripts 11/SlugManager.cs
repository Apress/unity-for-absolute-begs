﻿using UnityEngine;
using System.Collections;

public class SlugManager : MonoBehaviour {

	BatteryHealth batteryHealth; // the script
	public float life = 6f; // time to go through the garden

	// Use this for initialization
	void Start () {
	   batteryHealth = GameObject.Find("Battery Life").GetComponent<BatteryHealth>();
	   StartCoroutine (TimedDestroy()); // start timer for auto destroy
	}

	
	// Update is called once per frame
	void Update () {
	
	}
	
	IEnumerator TimedDestroy () {
	   yield return new WaitForSeconds(life);	
	   DestroySlug();
	}
		
	void DestroySlug () {
	   batteryHealth.running = false;	
	   Destroy(gameObject);
	}

	void OnCollisionEnter (Collision collision) {
	   if (collision.transform.tag == "Ammo") {
	      StartCoroutine (HitDestroy()); // if it was tagged as Ammo, process its destruction
	   }
	}
	
	IEnumerator HitDestroy () {
	   GetComponent<Animator>().Play("Slug Hit");
	   audio.Play(); // play death fx	
	   yield return new WaitForSeconds(1);
	   // reset battery	
		batteryHealth.batteryRemaining = batteryHealth.batteryFull / 2; // half charge
	   DestroySlug();
	}

	
}
