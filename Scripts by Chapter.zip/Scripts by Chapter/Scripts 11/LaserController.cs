﻿using UnityEngine;
using System.Collections;

public class LaserController : MonoBehaviour {
	
	Animator animator; // var to hold the animator component
	public GameObject laserPoint;
	
	internal bool activated; // flag to allow laser

	void OnEnable () {
	   animator = GetComponent <Animator>(); // assign the object's animator component
	   if (animator.layerCount >= 2) { // if there is more than one layer...
	      // set the Laser layer's weight to 1, (base layer is index 0, so Laser is 1)
	      animator.SetLayerWeight(1, 1f); // layer index, weight
	   } 
	}
	
	
	// Use this for initialization
	void Start () {
		BeamOff();
	}
	
	// Update is called once per frame
	void Update () {
		if (animator && activated) { // check for its existance and activation flag first
		   if(Input.GetButtonUp("Arm")) OpenHat ();
		   if(Input.GetButtonUp("Disarm")) CloseHat ();
			//check for hat state
			if(animator.GetCurrentAnimatorStateInfo(1).IsName("Laser.Gnome armed") ) BeamOn();
			else BeamOff();
		} // end if animator
	
	}
	
	public void OpenHat () {
	   animator.SetBool("Armed", true);
	   activated = true;
	}
	
	public void CloseHat () {
	   animator.SetBool("Armed", false);	
	}
	
	void BeamOn () {
	   laserPoint.SetActive(true);
	}
	
	void BeamOff () {
	   laserPoint.SetActive(false);
	}
	
	
}
