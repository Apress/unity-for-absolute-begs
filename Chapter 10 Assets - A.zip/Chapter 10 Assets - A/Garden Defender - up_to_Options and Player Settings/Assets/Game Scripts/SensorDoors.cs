﻿using UnityEngine;
using System.Collections;

public class SensorDoors : MonoBehaviour {
	
	public AnimationClip clipOpen; // the open animation
	public AnimationClip clipClose; // the close animation
	//public SmoothFollow follow; // the camera' SmoothFollow script
	
	// variable that can trigger 'game on'
	public bool canActivateGame = false; 
	
	//objects that must be informed of the 'game on' state
	public GameObject gardenHud; // where the batterysprites are & text controlled
	public SpawnBunnies bunnySpawner; // the SpawnBunnies script
	public BatteryHealth batteryLife; // the script for the battery charge (on Battery Life object)
	
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	// open the gates
	void OnTriggerEnter (Collider defender) {
	   if (defender.gameObject.tag == "Player") {
	      animation.Play(clipOpen.name);
		  audio.Play(); // play the clip loaded in the audio component
		  if (canActivateGame) SetGameOn(); // get the game under way
	   }
		//follow.distance = 1.15f; // change the SmoothFollow distance
		//follow.height = 0.5f; // change the SmoothFollow height

	}

	// close the gates
	void OnTriggerExit (Collider defender) {
	   if (defender.gameObject.tag == "Player") {
	      animation.Play(clipClose.name);
		  audio.Play(); // play the clip loaded in the audio component
	   }
		//follow.distance = 2.8f; // revert the SmoothFollow distance
		//follow.height = 1.8f; // revert the SmoothFollow height

	}

	void SetGameOn () {
	   // turn off the flag   
	   canActivateGame = false; 
	   // activate the Garden HUD sprites
	   gardenHud.GetComponent<ChildVisibility>().SpriteToggle(true);
	   // send a message to start the additional bunny drops 
	   bunnySpawner.StartCountdown(); 
	   // set battery drain on
	   batteryLife.trackingBattery = true;
	}

	
}
