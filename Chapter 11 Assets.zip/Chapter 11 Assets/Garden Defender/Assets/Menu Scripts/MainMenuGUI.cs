﻿using UnityEngine;
using System.Collections;

public class MainMenuGUI : MonoBehaviour {
	
	public GUISkin newSkin; // custom skin to use
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI () {
		
	   GUI.skin = newSkin;
			
	   // Constrain all drawing to be within a 600x600 pixel area centered on the screen.
	   GUI.BeginGroup (new Rect (Screen.width / 2 - 300, Screen.height / 2 - 350, 600, 600));
	
			// Draw a box in the new coordinate space defined by the BeginGroup.
			GUI.Box (new Rect (0,0,600,600),"Main Menu");
			
			int y = 265; // base Y position
			int x = 200; // base x inset
			int yOffset = 60; // y offset
			
			// Play Game
			if (GUI.Button( new Rect (x,y,200,40), "Play / Resume")) {
			   // start game 
			   Screen.showCursor = false; // hide the cursor
			   Application.LoadLevel("GardenLevel1");
			}
			y+= yOffset;
			// Settings
			if (GUI.Button( new Rect (x,y,200,40), "Settings")) {
			   // go to settings menu  
			   Application.LoadLevel("SettingsMenu");
			}
			y+= yOffset;
			// Quit
			if (GUI.Button( new Rect (x,y,200,40), "Credits")) {
			   // got to credits
			   Application.LoadLevel(3);
			}
			y+= yOffset;
			// Quit
			if (GUI.Button( new Rect (x,y,200,40), "Quit")) {
			   // quit application
			   Application.Quit();
			}
	
	   // must match all BeginGroup calls with an EndGroup
	   GUI.EndGroup ();
	}

	
}
