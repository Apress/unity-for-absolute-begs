﻿using UnityEngine;
using System.Collections;

public class UVAnimator : MonoBehaviour {

	public int materialIndex  = 0; // in case the object has more than one material
	public Material theMaterial; // the object's material[s]
	
	public bool animateUV = true; // flag for option to scroll texture
	public float scrollSpeedU1 = 0.0f; // variables to scroll texture
	public float scrollSpeedV1 = 0.0f;
	
	public  bool animateBump = false; // flag for option to scroll bump texture
	public  float scrollSpeedU2 = 0.0f; // variables to scroll bump texture
	public  float scrollSpeedV2 = 0.0f;

	
	// Use this for initialization
	void Start () {
		theMaterial = renderer.materials[materialIndex];
	}
	
	// Update is called once per frame
	void FixedUpdate  () {
		
		// texture offset variables
		float offsetU1 = Time.time  * -scrollSpeedU1;
		float offsetV1 = Time.time * -scrollSpeedV1;
		// animate the UVs
		if (animateUV) { // if the flag to animate the texture is true...
		   Vector2 offset1 = new Vector3(offsetU1,offsetV1);			
		   renderer.materials[materialIndex].SetTextureOffset ("_MainTex",offset1);
		}
		
		// bump texture offset variables
		if (animateBump) {
		   float offsetU2 = Time.time * -scrollSpeedU2;
		   float offsetV2 = Time.time * -scrollSpeedV2;
		   if (animateUV) { // if the flag to animate the texture is true...
		      Vector2 offset2 = new Vector3(offsetU2,offsetV2);
		      theMaterial.SetTextureOffset ("_BumpMap",offset2);
		   }
		}
	
	}
}
